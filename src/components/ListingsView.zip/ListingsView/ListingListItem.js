// src/components/ListingsView/ListingListItem.js
import React from 'react';

const ListingListItem = ({ listing }) => (
  <div className="flex bg-gradient-to-r from-green-50 to-white shadow-lg hover:shadow-2xl transition-shadow duration-300 rounded-lg overflow-hidden mb-6 border border-gray-300">
    {/* Sekcja ze zdjęciem i ceną */}
    <div className="w-1/3 relative border-r border-gray-300 rounded-l-lg overflow-hidden">
      <img
        src={listing.imgSrc || '/images/automobile-1834278_640.jpg'}
        alt={listing.title}
        className="w-full h-full object-cover rounded-l-lg"
      />
      
      {/* Cena na zdjęciu */}
      <div className="absolute bottom-0 w-full bg-green-700 bg-opacity-90 text-white text-center py-2 rounded-br-lg">
        <p className="text-lg font-semibold">
          {listing.price ? `$${listing.price}` : 'Cena do negocjacji'}
        </p>
      </div>
    </div>
    
    {/* Sekcja z treścią */}
    <div className="flex-1 p-6 flex flex-col justify-between bg-gradient-to-b from-gray-50 to-green-50">
      <div className="mb-4">
        <h3 className="text-2xl font-semibold text-gray-900 mb-2">{listing.title || 'Tytuł Ogłoszenia'}</h3>
        <p className="text-gray-700" style={{ minHeight: '4em', lineHeight: '1.5em', overflow: 'hidden' }}>
          {listing.description || 'Opis ogłoszenia: Dodaj szczegóły, takie jak rok produkcji, przebieg, typ paliwa itp.'}
        </p>
      </div>

      <div className="flex justify-center">
        <button className="bg-green-700 text-white px-5 py-2 rounded-md font-medium w-full max-w-xs text-center shadow-md hover:shadow-lg transition-shadow duration-300">
          Zobacz szczegóły
        </button>
      </div>
    </div>
  </div>
);

export default ListingListItem;
