// src/components/ListingsView/ListingCard.js
import React from 'react';

const ListingCard = ({ listing }) => (
  <div className="bg-white shadow-lg rounded-lg overflow-hidden mb-4 border border-gray-200 hover:shadow-xl transition-shadow duration-300">
    <img src={listing.imgSrc || '/images/automobile-1834278_640.jpg'} alt={listing.title} className="w-full h-48 object-cover" /> {/* Zwiększona wysokość */}
    <div className="p-6"> {/* Zwiększony padding */}
      <h3 className="text-2xl font-semibold text-gray-800">{listing.title}</h3> {/* Zwiększony rozmiar czcionki */}
      <p className="text-green-800 font-semibold text-xl mt-2">{listing.price}</p> {/* Zwiększony rozmiar czcionki */}
      <button className="mt-4 bg-green-800 text-white px-6 py-3 rounded-md text-lg hover:bg-green-700 transition-colors duration-300">
        Zobacz szczegóły
      </button>
    </div>
  </div>
);

export default ListingCard;
