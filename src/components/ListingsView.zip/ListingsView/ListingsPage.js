// src/components/ListingsView/ListingsPage.js
import React, { useState } from 'react';
import ListingCard from './ListingCard'; // Dla widoku kafelkowego
import ListingListItem from './ListingListItem'; // Dla widoku listowego
import ViewToggle from './ViewToggle';

const sampleListings = [
  { id: 1, title: '2022 Toyota RAV4 XLE', price: '$31,000', imgSrc: '/images/automobile-1834278_640.jpg' },
  { id: 2, title: '2019 Honda Accord Sport', price: '$25,000', imgSrc: '/images/dodge-challenger-8214392_640.jpg' },
  { id: 3, title: '2020 Ford F-150 Lariat', price: '$40,000', imgSrc: '/images/automobile-1834278_640.jpg' },
  { id: 4, title: '2021 BMW X5', price: '$50,000', imgSrc: '/images/car-2616096_640.jpg' },
  { id: 5, title: '2018 Audi A4', price: '$28,000', imgSrc: '/images/automobile-1834278_640.jpg' },
  { id: 6, title: '2022 Mercedes-Benz GLC', price: '$55,000', imgSrc: '/images/dodge-challenger-8214392_640.jpg' },
  { id: 7, title: '2020 Tesla Model 3', price: '$39,000', imgSrc: '/images/automobile-1834278_640.jpg' },
  { id: 8, title: '2019 Jeep Grand Cherokee', price: '$45,000', imgSrc: '/images/car-1880381_640.jpg' },
  { id: 9, title: '2021 Nissan Altima', price: '$27,000', imgSrc: '/images/toyota-gr-yaris-6751752_640.jpg' },
  { id: 10, title: '2022 Subaru Outback', price: '$30,000', imgSrc: '/images/dodge-challenger-8214392_640.jpg' },
  { id: 11, title: '2020 Chevrolet Silverado', price: '$35,000', imgSrc: '/images/automobile-1834278_640.jpg' },
  { id: 12, title: '2019 Ford Escape', price: '$22,000', imgSrc: '/images/car-2616096_640.jpg' },
  { id: 13, title: '2021 Honda Civic', price: '$21,000', imgSrc: '/images/automobile-1834278_640.jpg' },
  { id: 14, title: '2020 BMW 3 Series', price: '$41,000', imgSrc: '/images/dodge-challenger-8214392_640.jpg' },
];

const ListingsPage = () => {
  const [view, setView] = useState('list');
  const [currentPage, setCurrentPage] = useState(1);
  const listingsPerPage = 8;

  const indexOfLastListing = currentPage * listingsPerPage;
  const indexOfFirstListing = indexOfLastListing - listingsPerPage;
  const currentListings = sampleListings.slice(indexOfFirstListing, indexOfLastListing);
  const totalPages = Math.ceil(sampleListings.length / listingsPerPage);

  const handleToggleView = (viewType) => setView(viewType);
  const handlePageChange = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <div
      className="relative w-full min-h-screen bg-cover bg-center bg-fixed"
      style={{
        backgroundImage: `url('/images/car-932455_1920.jpg')`,
      }}
    >
      <div className="absolute inset-0 bg-black opacity-50 pointer-events-none"></div>

      <div className="relative container mx-auto max-w-screen-lg px-8 py-10">
        <ViewToggle view={view} onToggleView={handleToggleView} />
        
        {view === 'grid' ? (
          // Widok kafelkowy
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {currentListings.map((listing) => (
              <ListingCard key={listing.id} listing={listing} />
            ))}
          </div>
        ) : (
          // Widok listowy
          <div className="space-y-6">
            {currentListings.map((listing) => (
              <ListingListItem key={listing.id} listing={listing} />
            ))}
          </div>
        )}

        <div className="flex justify-center mt-10">
          {Array.from({ length: totalPages }, (_, index) => (
            <button
              key={index}
              onClick={() => handlePageChange(index + 1)}
              className={`px-4 py-2 mx-1 rounded ${currentPage === index + 1 ? 'bg-green-700 text-white' : 'bg-gray-300 text-gray-700'}`}
            >
              {index + 1}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ListingsPage;
