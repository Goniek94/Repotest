import React from 'react';

const ViewToggle = ({ view, onToggleView }) => (
  <div className="flex justify-end mb-4">
    {/* Przycisk "Widok listowy" jako pierwszy */}
    <button
      onClick={() => onToggleView('list')}
      className={`px-3 py-1 rounded-l-md ${view === 'list' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-700'}`}
    >
      Widok listowy
    </button>
    {/* Przycisk "Widok kafelkowy" jako drugi */}
    <button
      onClick={() => onToggleView('grid')}
      className={`px-3 py-1 rounded-r-md ${view === 'grid' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-700'}`}
    >
      Widok kafelkowy
    </button>
  </div>
);

export default ViewToggle;
