import React from 'react';

function ListingsList() {
  return <div>Lista ogłoszeń</div>;
}

export default ListingsList;
