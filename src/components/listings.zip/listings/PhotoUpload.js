import React, { useState } from 'react';

const PhotoUpload = ({ onPhotosChange }) => {
  const [photos, setPhotos] = useState([]);
  const [mainPhotoIndex, setMainPhotoIndex] = useState(null);

  // Funkcja obsługująca dodawanie zdjęć
  const handleAddPhoto = (e) => {
    const files = Array.from(e.target.files);
    const newPhotos = files.map(file => URL.createObjectURL(file));
    
    setPhotos(prevPhotos => [...prevPhotos, ...newPhotos]);
    if (onPhotosChange) onPhotosChange([...photos, ...newPhotos]);
  };

  // Funkcja obsługująca ustawienie zdjęcia głównego
  const handleSetMainPhoto = (index) => {
    setMainPhotoIndex(index);
  };

  return (
    <div className="flex flex-col items-center space-y-4">
      {/* Przycisk dodawania zdjęć */}
      <label className="bg-blue-500 text-white px-4 py-2 rounded cursor-pointer hover:bg-blue-600">
        Dodaj zdjęcie
        <input
          type="file"
          multiple
          accept="image/*"
          className="hidden"
          onChange={handleAddPhoto}
        />
      </label>

      {/* Sekcja miniatur zdjęć */}
      <div className="flex space-x-4 mt-4">
        {photos.map((photo, index) => (
          <div
            key={index}
            className={`relative w-24 h-24 border rounded ${
              index === mainPhotoIndex ? 'border-blue-500' : 'border-gray-300'
            }`}
          >
            {/* Miniatura zdjęcia */}
            <img
              src={photo}
              alt={`Zdjęcie ${index + 1}`}
              className="object-cover w-full h-full rounded"
            />
            {/* Przycisk ustawienia zdjęcia głównego */}
            <button
              onClick={() => handleSetMainPhoto(index)}
              className={`absolute bottom-0 left-0 right-0 text-xs text-white px-1 py-0.5 rounded-b ${
                index === mainPhotoIndex ? 'bg-blue-500' : 'bg-gray-800 opacity-75'
              }`}
            >
              {index === mainPhotoIndex ? 'Główne' : 'Ustaw jako główne'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PhotoUpload;
