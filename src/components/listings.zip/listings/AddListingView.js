import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const AddListingView = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { listingData } = location.state || {};

  if (!listingData) {
    navigate('/createlisting');
    return null;
  }

  return (
    <div className="bg-gray-100 min-h-screen p-8">
      <div className="max-w-5xl mx-auto bg-white p-8 rounded-lg shadow-xl">
        {/* Nagłówek */}
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-extrabold text-gray-900 mb-2">
            {listingData.title || 'Podgląd ogłoszenia'}
          </h1>
          <p className="text-xl text-gray-600">{listingData.headline}</p>
        </div>

        {/* Miejsce na główne zdjęcie */}
        <div className="mb-8 text-center">
          {listingData.mainPhoto ? (
            <img
              src={URL.createObjectURL(listingData.mainPhoto)}
              alt="Główne zdjęcie"
              className="w-64 h-64 object-cover rounded-full mx-auto shadow-md"
            />
          ) : (
            <div className="w-64 h-64 bg-gray-300 rounded-full mx-auto flex items-center justify-center shadow-md">
              <span className="text-gray-600 text-2xl">Brak zdjęcia</span>
            </div>
          )}
        </div>

        {/* Informacje o pojeździe */}
        <div className="mb-8 border border-gray-200 rounded-lg p-6 shadow-sm">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Informacje o pojeździe</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <p className="text-gray-700">
                <span className="font-semibold">Marka:</span> {listingData.brand || 'Nie podano'}
              </p>
              <p className="text-gray-700">
                <span className="font-semibold">Model:</span> {listingData.model || 'Nie podano'}
              </p>
              <p className="text-gray-700">
                <span className="font-semibold">Generacja:</span> {listingData.generation || 'Nie podano'}
              </p>
              <p className="text-gray-700">
                <span className="font-semibold">Wersja:</span> {listingData.version || 'Nie podano'}
              </p>
              <p className="text-gray-700">
                <span className="font-semibold">Rocznik:</span> {listingData.year || 'Nie podano'}
              </p>
              <p className="text-gray-700">
                <span className="font-semibold">Przebieg:</span> {listingData.mileage ? `${listingData.mileage} km` : 'Nie podano'}
              </p>
              <p className="text-gray-700">
                <span className="font-semibold">Paliwo:</span> {listingData.fuel || 'Nie podano'}
              </p>
            </div>
            <div>
              <p className="text-gray-700">
                <span className="font-semibold">Skrzynia biegów:</span> {listingData.transmission || 'Nie podano'}
              </p>
              <p className="text-gray-700">
                <span className="font-semibold">Napęd:</span> {listingData.drive || 'Nie podano'}
              </p>
              <p className="text-gray-700">
                <span className="font-semibold">Moc:</span> {listingData.power ? `${listingData.power} KM` : 'Nie podano'}
              </p>
              <p className="text-gray-700">
                <span className="font-semibold">Pojemność silnika:</span> {listingData.engineSize ? `${listingData.engineSize} cm³` : 'Nie podano'}
              </p>
              <p className="text-gray-700">
                <span className="font-semibold">Typ nadwozia:</span> {listingData.bodyType || 'Nie podano'}
              </p>
              <p className="text-gray-700">
                <span className="font-semibold">Kolor:</span> {listingData.color || 'Nie podano'}
              </p>
              <p className="text-gray-700">
                <span className="font-semibold">Liczba drzwi:</span> {listingData.doors || 'Nie podano'}
              </p>
            </div>
          </div>
        </div>

        {/* Opcje dodatkowe */}
        <div className="mb-8 border border-gray-200 rounded-lg p-6 shadow-sm">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Opcje dodatkowe</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <p className="text-gray-700">
                <span className="font-semibold">Auto przystosowane dla osób niepełnosprawnych:</span> {listingData.options.disabledAdapted ? 'Tak' : 'Nie'}
              </p>
              <p className="text-gray-700">
                <span className="font-semibold">Kierownica po prawej stronie:</span> {listingData.options.rightHandDrive ? 'Tak' : 'Nie'}
              </p>
            </div>
            <div>
              <p className="text-gray-700">
                <span className="font-semibold">Auto po tuningu:</span> {listingData.options.modified ? 'Tak' : 'Nie'}
              </p>
              <p className="text-gray-700">
                <span className="font-semibold">Pierwszy właściciel:</span> {listingData.options.firstOwner ? 'Tak' : 'Nie'}
              </p>
            </div>
          </div>
        </div>

        {/* Lokalizacja */}
        <div className="mb-8 border border-gray-200 rounded-lg p-6 shadow-sm">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Lokalizacja</h2>
          <p className="text-gray-700">
            <span className="font-semibold">Województwo:</span> {listingData.region || 'Nie podano'}
          </p>
          <p className="text-gray-700">
            <span className="font-semibold">Miejscowość:</span> {listingData.city || 'Nie podano'}
          </p>
        </div>

        {/* Cena i typ ogłoszenia */}
        <div className="mb-8 border border-gray-200 rounded-lg p-6 shadow-sm text-center">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Cena i Typ ogłoszenia</h2>
          <p className="text-4xl font-bold text-gray-800 mb-2">
            {listingData.price ? `${listingData.price} zł` : 'Cena do ustalenia'}
          </p>
          <p className="text-xl text-gray-700 mt-2">
            <span className="font-semibold">Typ:</span> {listingData.listingType === 'wyroznione' ? 'Wyróżnione' : 'Standardowe'}
          </p>
        </div>

        {/* Przyciski akcji */}
        <div className="mt-8 flex justify-center space-x-4">
          <button
            onClick={() => navigate('/createlisting')}
            className="bg-gray-500 text-white font-semibold py-2 px-6 rounded-lg shadow-md hover:bg-gray-600 transition duration-200"
          >
            Powrót do edycji
          </button>
          <button
            onClick={() => navigate('/payment')} // Przekierowanie do strony płatności
            className="bg-green-600 text-white font-semibold py-2 px-6 rounded-lg shadow-md hover:bg-green-700 transition duration-200"
          >
            Dodaj ogłoszenie
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddListingView;
