// src/components/listings/ListingForm.jsx
import React from 'react';

const ListingForm = ({ formData, onFormChange, onOptionsChange }) => {
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    if (type === 'checkbox' && name === 'tradeOptions') {
      let newTradeOptions = [...(formData.tradeOptions || [])];
      if (checked) {
        newTradeOptions.push(value);
      } else {
        newTradeOptions = newTradeOptions.filter((option) => option !== value);
      }
      onFormChange({ [name]: newTradeOptions });
    } else if (type === 'checkbox' && name.startsWith('options.')) {
      const optionName = name.split('.')[1];
      onOptionsChange({ [optionName]: checked });
    } else {
      onFormChange({ [name]: type === 'checkbox' ? checked : value });
    }
  };

  return (
    <div className="p-8 space-y-6 bg-white rounded-xl shadow-lg font-sans">
      {/* Tytuł ogłoszenia */}
      <div>
        <label className="block text-sm font-semibold text-gray-800">Tytuł</label>
        <input
          type="text"
          name="title"
          value={formData.title}
          placeholder="Automatyczne uzupełnienie z marki, modelu, generacji, rocznika, wersji"
          className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-600 focus:ring-green-600 sm:text-sm"
          onChange={handleChange}
        />
      </div>

      {/* Nagłówek */}
      <div>
        <label className="block text-sm font-semibold text-gray-800">Nagłówek</label>
        <input
          type="text"
          name="headline"
          value={formData.headline}
          placeholder="(Max znaków 60)"
          className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-600 focus:ring-green-600 sm:text-sm"
          onChange={handleChange}
        />
      </div>

      {/* Stan pojazdu */}
      <div className="space-y-2">
        <label className="block text-sm font-semibold text-gray-800">Stan pojazdu</label>
        <div className="flex space-x-6">
          <label className="flex items-center space-x-2 text-gray-800">
            <input
              type="radio"
              name="condition"
              value="Nowy"
              checked={formData.condition === 'Nowy'}
              className="form-radio text-green-600 focus:ring-green-600"
              onChange={handleChange}
            />
            <span>Nowy</span>
          </label>
          <label className="flex items-center space-x-2 text-gray-800">
            <input
              type="radio"
              name="condition"
              value="Używany"
              checked={formData.condition === 'Używany'}
              className="form-radio text-green-600 focus:ring-green-600"
              onChange={handleChange}
            />
            <span>Używany</span>
          </label>
        </div>
      </div>

      {/* Numer rejestracyjny i VIN */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-semibold text-gray-800">Nr rejestracyjny</label>
          <input
            type="text"
            name="registrationNumber"
            value={formData.registrationNumber}
            className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-600 focus:ring-green-600 sm:text-sm"
            onChange={handleChange}
          />
        </div>
        <div>
          <label className="block text-sm font-semibold text-gray-800">Numer VIN</label>
          <input
            type="text"
            name="vin"
            value={formData.vin}
            placeholder="Wpisz VIN"
            className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-600 focus:ring-green-600 sm:text-sm"
            onChange={handleChange}
          />
        </div>
      </div>

      {/* Opcje handlowe */}
      <div className="space-y-2">
        <label className="block text-sm font-semibold text-gray-800">Opcje handlowe</label>
        <div className="flex flex-wrap gap-4 mt-2">
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              name="tradeOptions"
              value="Sprzedaż"
              checked={formData.tradeOptions.includes('Sprzedaż')}
              onChange={handleChange}
              className="form-checkbox text-green-600"
            />
            <span>Sprzedaż</span>
          </label>
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              name="tradeOptions"
              value="Cesja leasingu"
              checked={formData.tradeOptions.includes('Cesja leasingu')}
              onChange={handleChange}
              className="form-checkbox text-green-600"
            />
            <span>Cesja leasingu</span>
          </label>
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              name="tradeOptions"
              value="Zamiana"
              checked={formData.tradeOptions.includes('Zamiana')}
              onChange={handleChange}
              className="form-checkbox text-green-600"
            />
            <span>Zamiana</span>
          </label>
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              name="tradeOptions"
              value="Najem długoterminowy"
              checked={formData.tradeOptions.includes('Najem długoterminowy')}
              onChange={handleChange}
              className="form-checkbox text-green-600"
            />
            <span>Najem długoterminowy</span>
          </label>
        </div>
      </div>

      {/* Dane techniczne pojazdu */}
      <div className="space-y-4 border-b border-gray-300 pb-6 pt-6">
        <h3 className="text-lg font-semibold text-gray-700">Dane techniczne pojazdu</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Typ nadwozia */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Nadwozie</label>
            <select
              name="bodyType"
              value={formData.bodyType}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            >
              <option value="">Wybierz typ nadwozia</option>
              <option value="Hatchback">Hatchback</option>
              <option value="Sedan">Sedan</option>
              <option value="Kombi">Kombi</option>
              <option value="Coupe">Coupe</option>
              <option value="Cabrio">Cabrio</option>
              <option value="SUV">SUV</option>
              <option value="Minivan">Minivan</option>
              <option value="Terenowe">Terenowe</option>
              <option value="Dostawcze">Dostawcze</option>
            </select>
          </div>

          {/* Marka */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Marka</label>
            <input
              type="text"
              name="brand"
              value={formData.brand}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            />
          </div>

          {/* Model */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Model</label>
            <input
              type="text"
              name="model"
              value={formData.model}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            />
          </div>

          {/* Generacja */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Generacja</label>
            <input
              type="text"
              name="generation"
              value={formData.generation}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            />
          </div>

          {/* Wersja modelu */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Wersja modelu</label>
            <input
              type="text"
              name="version"
              value={formData.version}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            />
          </div>

          {/* Rocznik */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Rocznik</label>
            <input
              type="text"
              name="year"
              value={formData.year}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            />
          </div>

          {/* Paliwo */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Paliwo</label>
            <select
              name="fuel"
              value={formData.fuel}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            >
              <option value="">Wybierz rodzaj paliwa</option>
              <option value="Diesel">Diesel</option>
              <option value="Benzyna">Benzyna</option>
              <option value="Benzyna + gaz">Benzyna + Gaz</option>
              <option value="Hybryda">Hybryda</option>
              <option value="Elektryczne">Elektryczne</option>
            </select>
          </div>

          {/* Pojemność silnika */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Pojemność silnika (cm³)</label>
            <input
              type="text"
              name="engineSize"
              value={formData.engineSize}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            />
          </div>

          {/* Moc */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Moc (KM)</label>
            <input
              type="text"
              name="power"
              value={formData.power}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            />
          </div>

          {/* Przebieg */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Przebieg (km)</label>
            <input
              type="text"
              name="mileage"
              value={formData.mileage}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            />
          </div>

          {/* Skrzynia biegów */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Skrzynia biegów</label>
            <select
              name="transmission"
              value={formData.transmission}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            >
              <option value="">Wybierz skrzynię biegów</option>
              <option value="Manualna">Manualna</option>
              <option value="Automatyczna">Automatyczna</option>
            </select>
          </div>

          {/* Napęd */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Napęd</label>
            <select
              name="drive"
              value={formData.drive}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            >
              <option value="">Wybierz napęd</option>
              <option value="Przód">Przód</option>
              <option value="Tył">Tył</option>
              <option value="4x4">4x4</option>
            </select>
          </div>

          {/* Bezkolizyjny */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Bezkolizyjny</label>
            <div className="flex space-x-4 mt-2">
              <label className="flex items-center">
                <input
                  type="radio"
                  name="accidentFree"
                  value="Tak"
                  checked={formData.accidentFree === 'Tak'}
                  onChange={handleChange}
                  className="form-radio text-green-600"
                />
                <span className="ml-2">Tak</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  name="accidentFree"
                  value="Nie"
                  checked={formData.accidentFree === 'Nie'}
                  onChange={handleChange}
                  className="form-radio text-green-600"
                />
                <span className="ml-2">Nie</span>
              </label>
            </div>
          </div>

          {/* Stan pojazdu */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Stan pojazdu</label>
            <select
              name="vehicleCondition"
              value={formData.vehicleCondition}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            >
              <option value="">Wybierz stan pojazdu</option>
              <option value="Bezwypadkowy">Bezwypadkowy</option>
              <option value="Uszkodzony">Uszkodzony</option>
              <option value="Do renowacji">Do renowacji</option>
            </select>
          </div>
        </div>
      </div>

      {/* Lokalizacja i specyfikacje */}
      <div className="space-y-4 border-b border-gray-300 pb-6 pt-6">
        <h3 className="text-lg font-semibold text-gray-700">Lokalizacja i specyfikacje</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Kolor */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Kolor</label>
            <input
              type="text"
              name="color"
              value={formData.color}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            />
          </div>

          {/* Liczba drzwi */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Liczba drzwi</label>
            <select
              name="doors"
              value={formData.doors}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            >
              <option value="">Wybierz liczbę drzwi</option>
              <option value="2/3">2/3</option>
              <option value="4/5">4/5</option>
            </select>
          </div>

          {/* Kraj pochodzenia */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Kraj pochodzenia</label>
            <input
              type="text"
              name="countryOfOrigin"
              value={formData.countryOfOrigin}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            />
          </div>

          {/* Waga */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Waga (kg)</label>
            <input
              type="text"
              name="weight"
              value={formData.weight}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            />
          </div>

          {/* Region */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Województwo</label>
            <input
              type="text"
              name="region"
              value={formData.region}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            />
          </div>

          {/* Miejscowość */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Miejscowość</label>
            <input
              type="text"
              name="city"
              value={formData.city}
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            />
          </div>

          {/* Ilość miejsc */}
          <div>
            <label className="block text-sm font-semibold text-gray-800">Ilość miejsc</label>
            <input
              type="number"
              name="seats"
              value={formData.seats}
              min="1"
              max="9"
              className="mt-2 block w-full rounded-md border border-gray-300 p-2"
              onChange={handleChange}
            />
          </div>
        </div>
      </div>

      {/* Opcje dodatkowe */}
      <div className="space-y-4 pt-6">
        <h3 className="text-lg font-semibold text-gray-700">Opcje dodatkowe</h3>
        <div className="flex flex-wrap gap-4">
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              name="options.disabledAdapted"
              checked={formData.options.disabledAdapted}
              className="form-checkbox text-green-600"
              onChange={handleChange}
            />
            <span>Auto przystosowane pod osobę niepełnosprawną</span>
          </label>
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              name="options.rightHandDrive"
              checked={formData.options.rightHandDrive}
              className="form-checkbox text-green-600"
              onChange={handleChange}
            />
            <span>Kierownica po prawej stronie</span>
          </label>
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              name="options.modified"
              checked={formData.options.modified}
              className="form-checkbox text-green-600"
              onChange={handleChange}
            />
            <span>Auto po tuningu</span>
          </label>
          <label className="flex items-center space-x-2">
            <input
              type="checkbox"
              name="options.firstOwner"
              checked={formData.options.firstOwner}
              className="form-checkbox text-green-600"
              onChange={handleChange}
            />
            <span>Pierwszy właściciel</span>
          </label>
        </div>
      </div>

      {/* Cena samochodu */}
      <div className="mt-6">
        <label className="block text-sm font-semibold text-gray-800">Cena samochodu</label>
        <input
          type="text"
          name="price"
          value={formData.price}
          placeholder="Cena w zł"
          className="mt-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-600 focus:ring-green-600 sm:text-sm"
          onChange={handleChange}
        />
      </div>
    </div>
  );
};

export default ListingForm;
