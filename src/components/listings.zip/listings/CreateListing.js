// src/components/listings/CreateListing.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import SearchSection from './SearchSection';
import ListingForm from './ListingForm';
import PhotoUpload from './PhotoUpload';

const CreateListing = () => {
  const navigate = useNavigate();

  // Stan formularza
  const [listingData, setListingData] = useState({
    title: '',
    headline: '',
    condition: '',
    registrationNumber: '',
    vin: '',
    tradeOptions: [],
    bodyType: '',
    brand: '',
    model: '',
    generation: '',
    version: '',
    year: '',
    fuel: '',
    engineSize: '',
    power: '',
    mileage: '',
    transmission: '',
    drive: '',
    accidentFree: '',
    vehicleCondition: '',
    color: '',
    doors: '',
    countryOfOrigin: '',
    weight: '',
    region: '',
    city: '',
    seats: '',
    options: {
      disabledAdapted: false,
      rightHandDrive: false,
      modified: false,
      firstOwner: false,
    },
    listingType: 'standardowe',
    price: '',
    photos: [],
  });

  const handleFormChange = (updatedData) => {
    setListingData((prevData) => ({
      ...prevData,
      ...updatedData,
    }));
  };

  const handleOptionsChange = (updatedOptions) => {
    setListingData((prevData) => ({
      ...prevData,
      options: {
        ...prevData.options,
        ...updatedOptions,
      },
    }));
  };

  const handlePhotosChange = (photos) => {
    setListingData((prevData) => ({
      ...prevData,
      photos,
    }));
  };

  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [carDescriptionAgreement, setCarDescriptionAgreement] = useState(false);

  const isFormValid = agreedToTerms && carDescriptionAgreement;

  const goToPreview = () => {
    navigate('/addlistingview', { state: { listingData } });
  };

  return (
    <div
      className="bg-cover bg-center min-h-screen font-sans flex items-center justify-center"
      style={{ backgroundImage: `url('/images/road-6745746_1920.jpg')` }}
    >
      <main className="w-full max-w-4xl mx-auto px-6 py-8 bg-white bg-opacity-90 rounded-lg shadow-lg">
        {/* Sekcja wyszukiwania */}
        <SearchSection />

        {/* Formularz ogłoszenia */}
        <ListingForm
          formData={listingData}
          onFormChange={handleFormChange}
          onOptionsChange={handleOptionsChange}
        />

        {/* Sekcja dodawania zdjęć */}
        <PhotoUpload className="h-80 mx-auto my-8" onPhotosChange={handlePhotosChange} />

        {/* Typ ogłoszenia */}
        <div className="my-8">
          <h3 className="text-lg font-semibold text-gray-700 mb-3 text-center">Wybierz Typ Ogłoszenia</h3>
          <div className="flex flex-col items-center space-y-3">
            <label className="flex items-center space-x-3 text-gray-700">
              <input
                type="radio"
                name="listingType"
                value="standardowe"
                checked={listingData.listingType === 'standardowe'}
                onChange={(e) => handleFormChange({ listingType: e.target.value })}
                className="form-radio text-green-600 focus:ring-green-600"
              />
              <span>Standardowe - 30 zł / 30 dni</span>
            </label>
            <label className="flex items-center space-x-3 text-gray-700">
              <input
                type="radio"
                name="listingType"
                value="wyroznione"
                checked={listingData.listingType === 'wyroznione'}
                onChange={(e) => handleFormChange({ listingType: e.target.value })}
                className="form-radio text-green-600 focus:ring-green-600"
              />
              <span>Wyróżnione - 50 zł / 30 dni</span>
            </label>
          </div>
        </div>

        {/* Checkboxy walidacyjne */}
        <div className="space-y-4">
          <div className="flex items-start">
            <input
              type="checkbox"
              id="agreeToTerms"
              checked={agreedToTerms}
              onChange={(e) => setAgreedToTerms(e.target.checked)}
              className="form-checkbox h-4 w-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
            />
            <label htmlFor="agreeToTerms" className="ml-2 text-sm text-gray-700">
              Oświadczam, że zapoznałem(-am) się i akceptuję{' '}
              <a href="/regulamin" className="text-blue-600 hover:underline">
                Regulamin serwisu
              </a>
              .
            </label>
          </div>
          <div className="flex items-start">
            <input
              type="checkbox"
              id="carDescriptionAgreement"
              checked={carDescriptionAgreement}
              onChange={(e) => setCarDescriptionAgreement(e.target.checked)}
              className="form-checkbox h-4 w-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
            />
            <label htmlFor="carDescriptionAgreement" className="ml-2 text-sm text-gray-700">
              Oświadczam, że podane informacje o pojeździe są zgodne ze stanem faktycznym i opisem w ogłoszeniu.
            </label>
          </div>
        </div>

        {/* Przycisk przejścia do podglądu */}
        <div className="mt-8 flex justify-center">
          <button
            onClick={goToPreview}
            disabled={!isFormValid}
            className={`py-3 px-8 rounded-lg font-semibold shadow-lg transition-all duration-200 ${
              isFormValid
                ? 'bg-green-600 text-white hover:bg-green-700'
                : 'bg-gray-400 text-gray-200 cursor-not-allowed'
            }`}
          >
            Przejdź do podglądu
          </button>
        </div>
      </main>
    </div>
  );
};

export default CreateListing;
