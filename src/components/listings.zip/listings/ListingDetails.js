import React from 'react';

const ListingDetails = () => {
  const listing = {
    title: 'Volkswagen Golf 1.4 TSI',
    price: '50 000 zł',
    location: 'Mazowieckie, Piotrków',
    make: 'Volkswagen',
    model: 'Golf',
    year: '2015',
    fuelType: 'Benzyna',
    mileage: '150 000 km',
    description: 'Mam na sprzedaż samochód Volkswagen Golf 1.4 TSI, rocznik 2015, w bardzo dobrym stanie.',
    contact: {
      phone: '500 350 950',
      email: 'jarek@gmail.com',
    },
    imageUrl: 'https://via.placeholder.com/600x400',
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-6">{listing.title}</h1>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Zdjęcie */}
        <div className="lg:col-span-2">
          <img src={listing.imageUrl} alt={listing.title} className="rounded-lg shadow-lg w-full" />
        </div>
        {/* Szczegóły */}
        <div className="bg-gray-100 p-6 rounded-lg shadow-lg">
          <h2 className="text-2xl font-bold text-green-700 mb-4">{listing.price}</h2>
          <ul className="space-y-2">
            <li><strong>Marka:</strong> {listing.make}</li>
            <li><strong>Model:</strong> {listing.model}</li>
            <li><strong>Rok produkcji:</strong> {listing.year}</li>
            <li><strong>Paliwo:</strong> {listing.fuelType}</li>
            <li><strong>Przebieg:</strong> {listing.mileage}</li>
          </ul>
          <h3 className="mt-6 text-lg font-semibold">Kontakt:</h3>
          <p>Telefon: {listing.contact.phone}</p>
          <p>Email: {listing.contact.email}</p>
        </div>
      </div>
      {/* Opis */}
      <div className="mt-8">
        <h3 className="text-xl font-semibold">Opis samochodu</h3>
        <p>{listing.description}</p>
      </div>
    </div>
  );
};

export default ListingDetails;
