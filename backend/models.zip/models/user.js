import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  phoneNumber: {
    type: String,
    required: true,
    validate: {
      validator: function(v) {
        return /^[0-9]{9,12}$/.test(v);
      },
      message: props => `${props.value} to nieprawidłowy numer telefonu!`
    }
  },
  password: {
    type: String,
    required: true,
    minlength: [8, 'Hasło musi mieć co najmniej 8 znaków.'],
    validate: {
      validator: function (v) {
        return /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(v);
      },
      message: 'Hasło musi zawierać co najmniej 1 wielką literę, 1 cyfrę oraz 1 znak specjalny.'
    }
  },
  dob: {
    type: Date,
    required: true,
    validate: {
      validator: function (value) {
        const now = new Date();
        const age = now.getFullYear() - value.getFullYear();
        return age >= 18;
      },
      message: 'Musisz mieć co najmniej 18 lat.'
    }
  },
  address: {
    street: { type: String, trim: true },
    city: { type: String, trim: true },
    state: { type: String, trim: true },
    zip: { type: String, trim: true }
  },
  role: {
    type: String,
    enum: ['user', 'moderator', 'admin'],
    default: 'user'
  },
  is2FAEnabled: {
    type: Boolean,
    default: false
  },
  twoFACode: {
    type: String,
    default: null
  },
  twoFACodeExpires: {
    type: Date,
    default: null
  },
  twoFARetryCount: {
    type: Number,
    default: 0
  },
  twoFABlockUntil: {
    type: Date,
    default: null
  },
  resetPasswordToken: String,
  resetPasswordExpires: Date
});

userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) {
    return next();
  }

  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

const User = mongoose.model('User', userSchema);
export default User;
