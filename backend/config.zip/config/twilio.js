import twilio from 'twilio';
import dotenv from 'dotenv';

// Załaduj zmienne środowiskowe z pliku .env
dotenv.config();

// Pobieranie zmiennych środowiskowych
const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const fromPhoneNumber = process.env.TWILIO_PHONE_NUMBER;

// Sprawdzanie, czy wszystkie zmienne środowiskowe są poprawnie ustawione
if (!accountSid || !authToken || !fromPhoneNumber) {
  throw new Error('Brakuje wymaganych zmiennych środowiskowych dla Twilio (TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER)');
}

// Tworzenie klienta Twilio
const client = twilio(accountSid, authToken);

// Funkcja do wysyłania kodu weryfikacyjnego
export const sendVerificationCode = (phoneNumber, code) => {
  console.log(`Wysyłanie kodu weryfikacyjnego do ${phoneNumber} z numeru ${fromPhoneNumber}.`);

  return client.messages.create({
    body: `Twój kod weryfikacyjny to: ${code}`,
    from: fromPhoneNumber,
    to: phoneNumber,
  }).then(message => {
    console.log(`Wiadomość wysłana, SID: ${message.sid}`);
  }).catch(error => {
    console.error('Błąd podczas wysyłania wiadomości:', error);
    throw error;
  });
};
