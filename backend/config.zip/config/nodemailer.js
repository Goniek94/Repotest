import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST, // Host SMTP, np. smtp.gmail.com
  port: process.env.EMAIL_PORT || 587, // Port SMTP, np. 587
  secure: false, // true dla portu 465, false dla portu 587
  auth: {
    user: process.env.EMAIL_USER, // Email nadawcy
    pass: process.env.EMAIL_PASS, // Hasło do emaila
  },
});

export const sendResetPasswordEmail = async (email, resetToken) => {
  const resetUrl = `${process.env.FRONTEND_URL}/reset-password?token=${resetToken}`;

  const mailOptions = {
    from: process.env.EMAIL_FROM, // Adres nadawcy
    to: email, // Adres odbiorcy
    subject: 'Resetowanie hasła',
    html: `<p>Kliknij poniższy link, aby zresetować hasło:</p><p><a href="${resetUrl}">${resetUrl}</a></p>`,
  };

  await transporter.sendMail(mailOptions);
};
