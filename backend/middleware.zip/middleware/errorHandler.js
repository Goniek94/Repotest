import ValidationError from '../errors/ValidationError.js';
import AuthorizationError from '../errors/AuthorizationError.js';
import CustomError from '../errors/CustomError.js';

const errorHandler = (err, req, res, next) => {
  if (err instanceof ValidationError) {
    return res.status(400).json({ message: err.message });
  }

  if (err instanceof AuthorizationError) {
    return res.status(403).json({ message: err.message });
  }

  if (err instanceof CustomError) {
    return res.status(err.statusCode || 500).json({ message: err.message });
  }

  console.error(err);
  res.status(500).json({ message: 'Wewnętrzny błąd serwera' });
};

export default errorHandler;
