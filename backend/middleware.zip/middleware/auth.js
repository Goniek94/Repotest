import jwt from 'jsonwebtoken';
import asyncHandler from 'express-async-handler';
import TokenBlacklist from '../models/TokenBlacklist.js'; // Import modelu czarnej listy tokenów

// Funkcja pomocnicza do weryfikacji tokena
const verifyToken = (token) => {
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      throw new Error('Token wygasł, zaloguj się ponownie.');
    } else if (err.name === 'JsonWebTokenError') {
      throw new Error('Token jest nieprawidłowy.');
    } else {
      throw new Error('Autoryzacja nie powiodła się.');
    }
  }
};

// Middleware autoryzacyjny
const auth = asyncHandler(async (req, res, next) => {
  const authHeader = req.header('Authorization');
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Brak tokena, autoryzacja odrzucona' });
  }

  const token = authHeader.split(' ')[1];

  // Sprawdź, czy token znajduje się na czarnej liście
  const blacklistedToken = await TokenBlacklist.findOne({ token });
  if (blacklistedToken) {
    return res.status(401).json({ message: 'Token unieważniony, wyloguj się ponownie.' });
  }

  try {
    // Zweryfikuj token przy użyciu funkcji pomocniczej
    const decoded = verifyToken(token);
    req.user = decoded; // Zapisz zdekodowane dane użytkownika w req.user
    next(); // Przejdź do następnej funkcji middleware lub trasy
  } catch (err) {
    return res.status(401).json({ message: err.message });
  }
});

// Eksport domyślny
export default auth;
