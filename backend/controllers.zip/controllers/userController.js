import crypto from 'crypto';
import { sendVerificationCode } from '../config/twilio.js'; 
import User from '../models/user.js';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { sendResetPasswordEmail } from '../config/nodemailer.js'; 
import { OAuth2Client } from 'google-auth-library';

const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

// Funkcja pomocnicza do obsługi błędów
const handleError = (res, message, error) => {
    res.status(500).json({ message, error });
};

// Wysyłanie kodu 2FA
export const send2FACode = async (req, res) => {
    const { phone, code } = req.body;

    try {
        await sendVerificationCode(phone, code); // Zakładam, że Twilio jest już skonfigurowane.
        res.status(200).json({ message: 'Kod weryfikacyjny został wysłany.' });
    } catch (error) {
        res.status(500).json({ message: 'Błąd podczas wysyłania kodu weryfikacyjnego.', error });
    }
};

// Rejestracja użytkownika z weryfikacją SMS (2FA)
export const registerUser = async (req, res) => {
    const { name, email, phone, password, dob } = req.body;

    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'Użytkownik o tym adresie email już istnieje.' });
        }

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);
        const code = Math.floor(100000 + Math.random() * 900000).toString();

        const user = new User({
            name, email, phone, password: hashedPassword, dob,
            is2FAEnabled: true, twoFACode: code, 
            twoFACodeExpires: Date.now() + 10 * 60 * 1000,
        });

        await sendVerificationCode(user.phone, code);
        await user.save();

        res.status(201).json({ message: 'Zarejestrowano, kod weryfikacyjny wysłany.' });
    } catch (error) {
        handleError(res, 'Błąd podczas rejestracji użytkownika', error);
    }
};

// Logowanie użytkownika
export const loginUser = async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: 'Użytkownik nie istnieje.' });
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Niepoprawne hasło.' });
        }

        const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.status(200).json({ token });
    } catch (error) {
        handleError(res, 'Błąd podczas logowania użytkownika', error);
    }
};

// Weryfikacja kodu 2FA
export const verify2FACode = async (req, res) => {
    const { email, code } = req.body;

    if (!/^\d{6}$/.test(code)) {
        return res.status(400).json({ message: 'Niepoprawny format kodu 2FA.' });
    }

    try {
        const user = await User.findOne({ email });
        if (!user || !user.is2FAEnabled) {
            return res.status(400).json({ message: '2FA nie jest włączone lub użytkownik nie istnieje.' });
        }

        if (user.twoFACodeExpires < Date.now()) {
            return res.status(400).json({ message: 'Kod wygasł. Proszę poprosić o nowy kod.' });
        }

        if (user.twoFACode === code) {
            user.twoFACode = null;
            user.twoFACodeExpires = null;
            await user.save();
            return res.status(200).json({ message: 'Kod weryfikacyjny poprawny, zalogowano.' });
        }

        res.status(400).json({ message: 'Niepoprawny kod weryfikacyjny.' });
    } catch (error) {
        handleError(res, 'Błąd podczas weryfikacji kodu.', error);
    }
};

// Google OAuth2
export const googleAuth = async (req, res) => {
    const { tokenId } = req.body;

    try {
        const ticket = await client.verifyIdToken({
            idToken: tokenId, audience: process.env.GOOGLE_CLIENT_ID,
        });

        const { email_verified, email, name } = ticket.getPayload();

        if (email_verified) {
            let user = await User.findOne({ email });
            if (!user) {
                user = new User({ name, email, is2FAEnabled: false });
                await user.save();
            }

            const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
            res.status(200).json({ token });
        } else {
            res.status(400).json({ message: 'Nie udało się zweryfikować konta Google.' });
        }
    } catch (error) {
        handleError(res, 'Błąd podczas logowania przez Google.', error);
    }
};

// Nadawanie ról (administrator)
export const updateUserRole = async (req, res) => {
    const { userId, newRole } = req.body;

    try {
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ message: 'Użytkownik nie znaleziony.' });
        }

        user.role = newRole;
        await user.save();

        res.status(200).json({ message: `Rola użytkownika zaktualizowana na ${newRole}.` });
    } catch (error) {
        handleError(res, 'Błąd podczas aktualizacji roli użytkownika.', error);
    }
};

// Reset hasła i zmiana hasła - wyciągnięte do pomocniczej funkcji
const resetPasswordHandler = async (user, password) => {
    const salt = await bcrypt.genSalt(10);
    user.password = await bcrypt.hash(password, salt);
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;
    await user.save();
};

// Resetowanie hasła
export const resetPassword = async (req, res) => {
    const { token, password } = req.body;

    try {
        const hashedToken = crypto.createHash('sha256').update(token).digest('hex');
        const user = await User.findOne({
            resetPasswordToken: hashedToken,
            resetPasswordExpires: { $gt: Date.now() },
        });

        if (!user) {
            return res.status(400).json({ message: 'Token jest nieprawidłowy lub wygasł.' });
        }

        await resetPasswordHandler(user, password);
        res.status(200).json({ message: 'Hasło zostało zresetowane.' });
    } catch (error) {
        handleError(res, 'Błąd podczas resetowania hasła.', error);
    }
};

// Generowanie tokenu resetu hasła
export const requestPasswordReset = async (req, res) => {
    const { email } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: 'Użytkownik z podanym adresem email nie istnieje.' });
        }

        const resetToken = crypto.randomBytes(20).toString('hex');
        user.resetPasswordToken = crypto.createHash('sha256').update(resetToken).digest('hex');
        user.resetPasswordExpires = Date.now() + 10 * 60 * 1000;

        await sendResetPasswordEmail(user.email, resetToken);
        await user.save();

        res.status(200).json({ message: 'Link do resetu hasła został wysłany.' });
    } catch (error) {
        handleError(res, 'Błąd podczas resetowania hasła.', error);
    }
};

// Zmiana hasła (wewnątrz profilu)
export const changePassword = async (req, res) => {
    const { userId } = req.user;
    const { oldPassword, newPassword } = req.body;

    try {
        const user = await User.findById(userId);
        if (!user) {
            return res.status(404).json({ message: 'Użytkownik nie znaleziony.' });
        }

        const isMatch = await bcrypt.compare(oldPassword, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: 'Niepoprawne stare hasło.' });
        }

        await resetPasswordHandler(user, newPassword);
        res.status(200).json({ message: 'Hasło zostało zmienione.' });
    } catch (error) {
        handleError(res, 'Błąd podczas zmiany hasła.', error);
    }
};
