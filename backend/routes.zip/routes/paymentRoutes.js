import express from 'express';
import auth from '../middleware/auth.js';
import Payment from '../models/payment.js';

const router = express.Router();

// Pobieranie historii płatności
router.get('/', auth, async (req, res) => {
  try {
    const payments = await Payment.find({ user: req.user.id }).sort({ transactionDate: -1 });
    res.status(200).json(payments);
  } catch (err) {
    res.status(500).json({ message: 'Błąd serwera' });
  }
});

// Dodawanie nowej transakcji
router.post('/', auth, async (req, res) => {
  const { amount, paymentMethod } = req.body;

  try {
    const payment = new Payment({
      user: req.user.id,
      amount,
      paymentMethod,
      status: 'completed' // Możesz zaktualizować status na podstawie wyników transakcji
    });

    await payment.save();
    res.status(201).json(payment);
  } catch (err) {
    res.status(500).json({ message: 'Błąd serwera' });
  }
});

export default router;
