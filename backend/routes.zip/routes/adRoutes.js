import express from 'express';
import { Router } from 'express';
import auth from '../middleware/auth.js';
import Ad from '../models/Ad.js';
import multer from 'multer';
import { CloudinaryStorage } from 'multer-storage-cloudinary';
import { v2 as cloudinary } from 'cloudinary';
import validate from '../middleware/validate.js';
import adValidationSchema from '../validationSchemas/adValidation.js';
import rateLimit from 'express-rate-limit';
import errorHandler from '../middleware/errorHandler.js';

// Konfiguracja Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET
});

// Konfiguracja Multer-Storage-Cloudinary
const storage = new CloudinaryStorage({
  cloudinary: cloudinary,
  params: {
    folder: 'ads',
    allowedFormats: ['jpg', 'jpeg', 'png'],
    transformation: [{ width: 800, height: 600, crop: 'limit' }]
  }
});

const upload = multer({ storage: storage });

const router = Router();

// Limiter dla trasy dodawania ogłoszenia
const createAdLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  message: 'Zbyt wiele prób dodania ogłoszenia. Spróbuj ponownie za 15 minut.'
});

// Funkcja pomocnicza do tworzenia filtru ogłoszeń
const createAdFilter = ({ make, model, minPrice, maxPrice }) => {
  const filter = {};
  if (make) filter.make = make;
  if (model) filter.model = model;
  if (minPrice || maxPrice) {
    filter.price = {};
    if (minPrice) filter.price.$gte = parseFloat(minPrice);
    if (maxPrice) filter.price.$lte = parseFloat(maxPrice);
  }
  return filter;
};

// Dodawanie ogłoszenia z walidacją i weryfikacją zdjęć
router.post('/add', auth, createAdLimiter, upload.array('images', 10), validate(adValidationSchema), async (req, res, next) => {
  try {
    const {
      make, model, year, price, mileage, fuelType, transmission, vin,
      registrationNumber, description, purchaseOptions, listingType
    } = req.body;

    const images = req.files.map(file => file.path);

    const newAd = new Ad({
      make,
      model,
      year,
      price,
      mileage,
      fuelType,
      transmission,
      vin,
      registrationNumber,
      description,
      images,
      purchaseOptions,
      listingType,
      owner: req.user._id,
      status: 'w toku'
    });

    const ad = await newAd.save();
    res.status(201).json(ad);
  } catch (err) {
    next(err);
  }
}, errorHandler);

// Paginacja, filtrowanie i sortowanie ogłoszeń
router.get('/', async (req, res, next) => {
  const { page = 1, limit = 10, make, model, minPrice, maxPrice, sortBy = 'createdAt', order = 'desc' } = req.query;

  const filter = createAdFilter({ make, model, minPrice, maxPrice });
  const sortOrder = order === 'desc' ? -1 : 1;

  try {
    const ads = await Ad.find(filter)
      .select('make model price year views')
      .sort({ [sortBy]: sortOrder })
      .limit(parseInt(limit))
      .skip((parseInt(page) - 1) * parseInt(limit));

    const totalAds = await Ad.countDocuments(filter);

    res.status(200).json({
      ads,
      totalPages: Math.ceil(totalAds / limit),
      currentPage: parseInt(page),
    });
  } catch (err) {
    next(err);
  }
}, errorHandler);

// Zmiana statusu ogłoszenia
router.put('/:id/status', auth, async (req, res, next) => {
  const { status } = req.body;

  if (!['w toku', 'opublikowane', 'archiwalne'].includes(status)) {
    return res.status(400).json({ message: 'Nieprawidłowy status ogłoszenia' });
  }

  try {
    const ad = await Ad.findById(req.params.id);

    if (!ad) {
      return res.status(404).json({ message: 'Ogłoszenie nie znalezione' });
    }

    ad.status = status;
    await ad.save();

    res.status(200).json({ message: 'Status ogłoszenia zaktualizowany', ad });
  } catch (err) {
    next(err);
  }
}, errorHandler);

// Pobieranie szczegółów ogłoszenia oraz aktualizacja wyświetleń
router.get('/:id', async (req, res, next) => {
  try {
    const ad = await Ad.findById(req.params.id);

    if (!ad) {
      return res.status(404).json({ message: 'Ogłoszenie nie znalezione' });
    }

    ad.views += 1;
    await ad.save();

    res.status(200).json(ad);
  } catch (err) {
    next(err);
  }
}, errorHandler);

export default router;
