import express from 'express';
import {
  registerUser,
  loginUser,
  send2FACode,
  verify2FACode,
  updateUserRole,
  requestPasswordReset,
  resetPassword,
  changePassword
} from '../controllers/userController.js';

import { body, validationResult } from 'express-validator';
import roleCheck from '../middleware/roleMiddleware.js';
import auth from '../middleware/auth.js'; // Middleware do autoryzacji użytkownika

const router = express.Router();

// Rejestracja użytkownika
router.post(
  '/register',
  [
    body('name')
      .trim()
      .escape()
      .notEmpty()
      .withMessage('Imię jest wymagane.')
      .isLength({ min: 2 })
      .withMessage('Imię musi zawierać co najmniej 2 znaki.'),
    body('email')
      .normalizeEmail()
      .isEmail()
      .withMessage('Nieprawidłowy format email.'),
    body('password')
      .isStrongPassword({
        minLength: 8,
        minUppercase: 1,
        minNumbers: 1,
        minSymbols: 1
      })
      .withMessage('Hasło musi mieć co najmniej 8 znaków, jedną wielką literę, jedną cyfrę i jeden znak specjalny.'),
    body('phone')
      .matches(/^[0-9]{9,12}$/)
      .withMessage('Numer telefonu powinien zawierać 9-12 cyfr.'),
    body('dob')
      .isDate()
      .withMessage('Nieprawidłowa data urodzenia.')
      .custom((value) => {
        if (new Date(value) >= new Date()) {
          throw new Error('Data urodzenia musi być z przeszłości.');
        }
        return true;
      }),
    body('termsAccepted')
      .equals('true')
      .withMessage('Musisz zaakceptować warunki korzystania.')
  ],
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    registerUser(req, res, next);
  }
);

// Logowanie użytkownika
router.post(
  '/login',
  [
    body('email')
      .normalizeEmail()
      .isEmail()
      .withMessage('Nieprawidłowy format email.'),
    body('password')
      .notEmpty()
      .withMessage('Hasło jest wymagane.')
  ],
  (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    loginUser(req, res, next);
  }
);

// Wysyłanie kodu SMS 2FA
router.post('/send-2fa', send2FACode);

// Weryfikacja kodu 2FA
router.post('/verify-2fa', verify2FACode);

// Nadawanie ról (administrator)
router.put('/update-role', auth, roleCheck(['admin']), updateUserRole);

// Żądanie resetu hasła
router.post(
  '/request-reset-password',
  [
    body('email').isEmail().withMessage('Proszę podać prawidłowy adres email.')
  ],
  requestPasswordReset
);

// Resetowanie hasła
router.post(
  '/reset-password',
  [
    body('password')
      .isStrongPassword({
        minLength: 8,
        minUppercase: 1,
        minNumbers: 1,
        minSymbols: 1
      })
      .withMessage('Hasło musi mieć co najmniej 8 znaków, jedną wielką literę, jedną cyfrę i jeden znak specjalny.'),
    body('token').notEmpty().withMessage('Token resetu hasła jest wymagany.')
  ],
  resetPassword
);

// Zmiana hasła w profilu użytkownika
router.put('/change-password', auth, [
  body('oldPassword').notEmpty().withMessage('Stare hasło jest wymagane.'),
  body('newPassword')
    .isStrongPassword({
      minLength: 8,
      minUppercase: 1,
      minNumbers: 1,
      minSymbols: 1
    })
    .withMessage('Nowe hasło musi mieć co najmniej 8 znaków, jedną wielką literę, jedną cyfrę i jeden znak specjalny.')
], changePassword);

export default router;
